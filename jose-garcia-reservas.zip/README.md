# José García Transporte — Reservas independientes

Sitio estático compatible con GitHub Pages. Abrir `index.html` en un navegador para usar el formulario. El botón prepara un mensaje a WhatsApp; **no confirma ni guarda reservas automáticamente**.

## Ubicaciones no incluidas
El cliente puede elegir «✍️ Escribir otra ubicación (cotizar)» en **origen**, **destino** o ambos, introducir el lugar y enviar su solicitud. Las rutas sin precio se muestran como «A cotizar».

## Agregar ubicaciones y tarifas para todos los clientes
Editar el archivo público `rutas-personalizadas.json` en el repositorio y publicar los cambios. Ejemplo:

```json
{
  "lugares": [{"id":"samana","nombre":"Samaná Centro"}],
  "tarifas": [{"origen":"sdq","destino":"samana","usd":185}]
}
```

El identificador `id` debe ser único y solo tener letras minúsculas sin acentos, números, guiones o guion bajo. Los nombres existentes para referirse a rutas incluyen: `sdq`, `boca`, `juan`, `colonial`, `centro`, `sanpedro`, `romana`, `bayahibe`, `punta`, `uvero`. Las tarifas son bidireccionales. No publicar una tarifa hasta que esté acordada.

Para que las nuevas ubicaciones aparezcan en **todos los teléfonos**, es necesario actualizar este archivo en el sitio publicado; las preferencias guardadas solo en un navegador no serían suficientes.

## Publicación
Crear repositorio público, cargar `index.html`, `rutas-personalizadas.json` y `README.md` en la raíz y activar GitHub Pages desde `main` / raíz. Una vez publicado, el QR debe apuntar a la URL pública exacta. No hay backend, base de datos ni panel de administración autenticado.

## Cálculo
Ida y vuelta del mismo día con hasta cuatro horas de espera: precio de ida × 2 × 0.78. Para más de cuatro pasajeros o rutas desconocidas se solicita cotización.
